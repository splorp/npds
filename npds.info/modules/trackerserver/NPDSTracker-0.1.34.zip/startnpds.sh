#!/bin/bash
export PATH=$PATH:/usr/local/j2sdk1.4.2/bin
cd /home/npds
nohup java npdstracker &
